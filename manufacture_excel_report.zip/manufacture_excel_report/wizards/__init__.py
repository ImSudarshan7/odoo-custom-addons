# -*- coding: utf-8 -*-

from . import mrp_detail_reports
