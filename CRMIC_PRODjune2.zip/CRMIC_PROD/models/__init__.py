from .import oder
from .import sales
from .import purchase
from .import res_partner
from .import stock_picking