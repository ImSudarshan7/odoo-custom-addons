from odoo import models, api

class Production(models.Model):
    _inherit = 'mrp.production'